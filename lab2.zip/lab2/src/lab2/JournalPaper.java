package lab2;

public class JournalPaper extends WrittenItem {
	public JournalPaper(String author) {
		super(author);
		System.out.println("'Inside JournalPaper'");
	}

	private int year;
	
	void printyear(int year) {
		 this.year=year;		
	     System.out.println("The Year of Journal Published is :"+this.year);
		
	}

}




