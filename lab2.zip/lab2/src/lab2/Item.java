package lab2;



	public abstract class Item {
		private int uniqueID;
		private int numberofCopies;
		private String title;
		
		public abstract void checkIn(int id);
		public abstract void checkOut(int id);
		
		public Item() {
			System.out.println("'Inside Super Class : item'");
			
		}

		public Item(int uniqueID, int numberofCopies, String title) {
			super();
			this.uniqueID = uniqueID;
			this.numberofCopies = numberofCopies;
			this.title = title;
		}

		public int getUniqueID() {
			return uniqueID;
		}

		public void setUniqueID(int uniqueID) {
			this.uniqueID = uniqueID;
		}


		public int getNumberofCopies() {
			return numberofCopies;
		}


		public void setNumberofCopies(int numberofCopies) {
			this.numberofCopies = numberofCopies;
		}


		public String getTitle() {
			return title;
		}


		public void setTitle(String title) {
			this.title = title;
		}

		@Override
		public String toString() {
return "Item [uniqueID=" + uniqueID + ", numberofCopies=" + numberofCopies + ", title=" + title +"]";
		}
	}
		
		
		

		


