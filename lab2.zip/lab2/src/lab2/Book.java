package lab2;

public class Book extends WrittenItem {
	
	public Book(String author) {
		super(author);
		
	}




}
